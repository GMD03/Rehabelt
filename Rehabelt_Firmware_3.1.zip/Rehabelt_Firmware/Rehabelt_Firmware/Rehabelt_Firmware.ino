#include <WiFi.h>
#include "FS.h"
#include "SD.h"
#include "SPI.h"
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>
#include <Wire.h>
#include <EloquentTinyML.h> // ML Library
#include "model_data.h"     // Trained model

// CONFIGURATIONS 
#define CS_PIN 5               
#define WINDOW_SIZE 100        // 2 seconds @ 50Hz
#define NUMBER_OF_INPUTS 600   // 100 samples * 6 axes
#define NUMBER_OF_OUTPUTS 4    // Walk, Sit, Supine, Unrecognized
#define TENSOR_ARENA_SIZE 50000 // Safe buffer for CNN operations

// CALIBRATION VALUES 
// PASTE VALUES FROM PYTHON OUTPUT 
float MODEL_MEAN[] = { 4.41356022e+00, 4.41356022e+02, 7.35813104e-02, -8.54193334e-01, 2.07999215e-02, 1.71881990e+00}; 
float MODEL_SCALE[] = { 2.92318147e+00, 2.92318147e+02, 3.86334882e-01, 3.58623749e-01, 2.47383006e-01, 2.35500859e+01 }; 

// ML Objects
Adafruit_MPU6050 mpu;
Eloquent::TinyML::TfLite<NUMBER_OF_INPUTS, NUMBER_OF_OUTPUTS, TENSOR_ARENA_SIZE> classifier;

// Globals
float sensorBuffer[WINDOW_SIZE][6]; 
int sampleIndex = 0;                


// SECTION A: SENSOR READING
void getRealTimeSensorData(float* ax, float* ay, float* az, float* gx, float* gy, float* gz) {
    sensors_event_t a, g, temp;
    mpu.getEvent(&a, &g, &temp);

    *ax = a.acceleration.x;
    *ay = a.acceleration.y;
    *az = a.acceleration.z;
    *gx = g.gyro.x;
    *gy = g.gyro.y;
    *gz = g.gyro.z;
}

// SECTION B: GAIT METRICS 
void calculateGaitMetrics() {
    Serial.println("[METRICS] Calculating Step Count & Sway...");
    // Add specific gait logic here if needed later
}

// SECTION C: CLASSIFIER (CNN)
int runModel() {
    float flatInput[WINDOW_SIZE * 6];
    
    for (int i = 0; i < WINDOW_SIZE; i++) {
        for (int j = 0; j < 6; j++) {
            flatInput[(i * 6) + j] = sensorBuffer[i][j];
        }
    }
    
    // Run Prediction
    float prediction[NUMBER_OF_OUTPUTS] = {0};
    classifier.predict(flatInput, prediction);
    
    // Find highest probability
    int bestClass = 0;
    float maxProb = prediction[0];
    
    for (int i = 1; i < NUMBER_OF_OUTPUTS; i++) {
        if (prediction[i] > maxProb) {
            maxProb = prediction[i];
            bestClass = i;
        }
    }
    
    // Optional: 
    Serial.print("Confidence: "); Serial.println(maxProb);
    
    // Optional:
    if (maxProb < 0.60) return 3; // Return Unrecognized if unsure
    
    return bestClass;
}

// SECTION D: LOGGING
void logToSD(String activity) {
    File file = SD.open("/history.csv", FILE_APPEND);
    if(file){
        file.print(millis());
        file.print(",");
        file.println(activity);
        file.close();
    } else {
        Serial.println("ERR: SD Write Failed");
    }
}

// MAIN SETUP
void setup() {
    Serial.begin(115200);
    delay(1000);

    // SD Card
    if (!SD.begin(CS_PIN)) Serial.println("SD Card Not Found...");
    else Serial.println("SD Card Ready");

    // Initialize MPU6050
    if (!mpu.begin()) {
        Serial.println("MPU6050 NOT FOUND! Check wiring.");
        while (1) delay(10);
    }
    Serial.println("MPU6050 Ready");
    
    mpu.setAccelerometerRange(MPU6050_RANGE_8_G);
    mpu.setGyroRange(MPU6050_RANGE_500_DEG);
    mpu.setFilterBandwidth(MPU6050_BAND_21_HZ);

    // Initialize ML Model
    classifier.begin(model_data);
    Serial.println("CNN Model Loaded Successfully");
}

// MAIN LOOP (50Hz)
void loop() {
    float ax, ay, az, gx, gy, gz;

    getRealTimeSensorData(&ax, &ay, &az, &gx, &gy, &gz);

    sensorBuffer[sampleIndex][0] = (ax - MODEL_MEAN[0]) / MODEL_SCALE[0];
    sensorBuffer[sampleIndex][1] = (ay - MODEL_MEAN[1]) / MODEL_SCALE[1];
    sensorBuffer[sampleIndex][2] = (az - MODEL_MEAN[2]) / MODEL_SCALE[2];
    sensorBuffer[sampleIndex][3] = (gx - MODEL_MEAN[3]) / MODEL_SCALE[3];
    sensorBuffer[sampleIndex][4] = (gy - MODEL_MEAN[4]) / MODEL_SCALE[4];
    sensorBuffer[sampleIndex][5] = (gz - MODEL_MEAN[5]) / MODEL_SCALE[5];

    sampleIndex++;

    if (sampleIndex >= WINDOW_SIZE) {
        
        unsigned long startTime = millis();
        int result = runModel();
        unsigned long duration = millis() - startTime;
        
        String status = "";

        // Map Result to Name
        if (result == 0) {
            status = "WALKING";
            calculateGaitMetrics();
        } 
        else if (result == 1) status = "SIT_TO_STAND";
        else if (result == 2) status = "SUPINE_TO_SIT";
        else if (result == 3) {
            status = "UNRECOGNIZED";
            Serial.println("Movement unclear.");
        }

        Serial.print("Detected: "); Serial.print(status);
        Serial.print(" (Took "); Serial.print(duration); Serial.println("ms)");
        
        logToSD(status);

        sampleIndex = 0; // Reset Buffer
    }

    delay(20); 
}